#' Detrend and Cut Data
#'
#' Performs detrending on time series data using various methods and optionally truncates the series.
#'
#' @param data A data frame containing time series data. Must include columns `x`, `y`, and `class`.
#' @param dettype A character string specifying the detrending method. Options are `"none"`, `"gaussian"`, `"1st diff"`, or `"asclassif"`.
#' @param cut Logical. If `TRUE`, truncates data for "abrupt" classifications at the change point.
#'
#' @return A data frame with added columns for detrended values (`y_res`) and, if applicable, modeled values (`y_model`).

detandcut <- function(data, dettype = "none", cut = TRUE) {

  # Gaussian detrending
  if (dettype == "gaussian") {
    data$y_model <- ksmooth(1:length(data$y), data$y, kernel = "normal",
                            bandwidth = round(bw.nrd0(1:length(data$y))),
                            range.x = range(1:length(data$y)),
                            x.points = 1:length(data$y))$y
    data$y_res <- data$y - data$y_model
  }

  # Classification-based detrending
  else if (dettype == "asclassif") {
    if (unique(as.character(data$class)) == "abrupt") {
      breakP <- unique(data$loc_brk_chg)
      data$y_model <- c(rep(mean(data$y[data$x <= breakP]), sum(data$x <= breakP)),
                        rep(mean(data$y[data$x > breakP]), sum(data$x > breakP)))
      data$y_res <- data$y - data$y_model
    }
    else if (unique(as.character(data$class)) == "quadratic") {
      linear_model <- lm(y ~ poly(x, 2, raw = TRUE), data = data)
      data$y_model <- linear_model$fitted.values
      data$y_res <- linear_model$residuals
    }
    else if (unique(as.character(data$class)) == "linear") {
      linear_model <- lm(y ~ x, data = data)
      data$y_model <- linear_model$fitted.values
      data$y_res <- linear_model$residuals
    }
    else {
      data$y_model <- mean(data$y)
      data$y_res <- data$y - data$y_model
    }
  }
  else if (dettype == "1st diff") {
    data$y_res <- c(diff(data$y),NA)
    data$y_model <- data$y_res
  }
  else if (dettype == "none"){
    data$y_res <- data$y
    data$y_model <- data$y_res
  }
  # Invalid detrending type
  else {
    stop("Invalid value for 'dettype'. Choose 'none', 'gaussian', '1st diff', or 'asclassif'.")
  }

  # Cutting data if class is "abrupt" and cut = TRUE
  if (dettype == "asclassif" & cut == TRUE) {
    breakP <- unique(data$loc_brk_chg)
    if (unique(as.character(data$class)) == "abrupt") {
      data <- data %>% filter(x <= breakP)
    }
  }

  return(data)
}


#' Calculate Metrics for Time Series Data
#'
#' Computes a variety of metrics (full-sample and rolling window) for time series data.
#'
#' @param data A data frame with time series data. Must include columns `y` and `y_res`.
#' @param metrics.type A character string specifying the type of metrics to compute: `"all"`, `"full"`, or `"roll"`.
#' @param winsize Numeric. The rolling window size as a percentage of the total series length.
#'
#' @return A data frame with columns for various metrics (e.g., disparity, CV, skewness, etc.)

calc_metrics <- function(data, metrics.type="all", winsize=50) {

  if (!metrics.type %in% c("all", "full", "roll")) {
    stop("Invalid type. Choose 'all', 'full', or 'roll'.")
  }

  data <- data[!is.na(data$y_res), ]

  if (metrics.type=="all") {

    # Calculate Jacobian eigenvalues
    DEV <- uni_smap_jacobian(data.frame(1:length(data$y), data$y))
    data$DEV.full <- DEV$eigenJ
    data$DEV.roll <- calc_kendall_corr(DEV$smapJ)$correlation

    # Full-sample metrics (non-detrended)
    data$disparity.full <- rep(disparity_index(
      norm_ts(data$y, type = "unity") +
        0.01*mean(norm_ts(data$y, type = "unity")))$disparity_index, nrow(data))
    data$mean.full <- mean(data$y)
    data$CV.full <- sd(data$y) / mean(data$y)
    data$dispersion.full <- sd(data$y) * sd(data$y) / mean(data$y)
    data$SD.full <- sd(data$y)
    data$skew.full <- skewness(data$y_res)
    data$ar1.full <- acf(data$y_res, plot = FALSE, lag.max = 1)$acf[2]
    data$kurtosis.full <- kurtosis(data$y_res)
    data$trend.full <- theil_sen(data$y)

    # Rolling metrics for non-detrended series
    non.det <- calc_roll_metrics(data$y, winsize)

    # Rolling metrics for detrended series
    det <- calc_roll_metrics(data$y_res, winsize)

    # Rolling window metrics (non-detrended)
    data$disparity.roll <- non.det$disparity.tau
    data$mean.roll <- non.det$mean.tau
    data$CV.roll <- non.det$CV.tau
    data$dispersion.roll <- non.det$dispersion.tau
    data$ar1.roll <- det$ar1.tau
    data$SD.roll <- non.det$SD.tau
    data$skew.roll <- det$skew.tau
    data$kurtosis.roll <- det$kurtosis.tau

  }
  else if (metrics.type=="roll") {

    # Rolling metrics for non-detrended series
    non.det <- calc_roll_metrics(data$y, winsize)

    # Rolling metrics for detrended series
    det <- calc_roll_metrics(data$y_res, winsize)

    # Rolling window metrics (non-detrended)
    data$disparity.roll <- non.det$disparity.tau
    data$mean.roll <- non.det$mean.tau
    data$CV.roll <- non.det$CV.tau
    data$dispersion.roll <- non.det$dispersion.tau
    data$ar1.roll <- det$ar1.tau  # AR1 uses detrended series
    data$SD.roll <- non.det$SD.tau
    data$skew.roll <- det$skew.tau  # Skewness uses detrended series

  }
  else {

    # Calculate Jacobian eigenvalues
    DEV <- uni_smap_jacobian(data.frame(1:length(data$y), data$y))
    data$DEV.full <- DEV$eigenJ
    data$DEV.roll <- cor(1:length(unlist(DEV$smapJ)),
                         unlist(DEV$smapJ), method = "kendall")

    # Full-sample metrics (non-detrended)
    data$disparity.full <- rep(disparity_index(
      norm_ts(data$y, type = "unity") +
        0.01*mean(norm_ts(data$y, type = "unity")))$disparity_index, nrow(data))
    data$mean.full <- mean(data$y)
    data$CV.full <- sd(data$y) / mean(data$y)
    data$dispersion.full <- sd(data$y) * sd(data$y) / mean(data$y)
    data$SD.full <- sd(data$y)
    data$skew.full <- skewness(data$y_res)
    data$ar1.full <- acf(data$y_res, plot = FALSE, lag.max = 1)$acf[2]

  }

  return(data)
}


#' Estimate Jacobian from Univariate Time Series
#'
#' Calculates Jacobian matrix estimates and eigenvalues for a univariate time series using S-map.
#'
#' @param data A data frame with columns representing time indices and values.
#' @param theta_seq A numeric vector of candidate theta values for optimization.
#' @param E Integer. Embedding dimension for state-space reconstruction.
#' @param tau Integer. Time lag for state-space reconstruction.
#' @param scale Logical. If `TRUE`, scales the time series before analysis.
#'
#' @return A list containing Jacobian matrices, eigenvalues, and additional statistics.

uni_smap_jacobian <- function(data = data.frame(1:length(data$y), data$y),
                              theta_seq = NULL, E = 1, tau = NULL, scale = TRUE) {
  if (E <= 0) {
    stop("E must be positive")
  }
  if (is.null(theta_seq)) {
    theta_seq <- c(0, 1e-04, 3e-04, 0.001, 0.003, 0.01,
                   0.03, 0.1, 0.3, 0.5, 0.75, 1, 1.5, 2, 3, 4, 6, 8)
  }
  if (is.null(tau)) {
    tau <- 1 * floor(dim(data)[1] * 0.1)
  }
  if (tau == 0) {
    tau <- 1
  }
  if (length(unique(data[, 2])) == 1 |
      (sum(as.numeric(base::table(data[,2]) == 1)) == 1 & length(unique(data[, 2])) == 2)) {
    smap_results <- rep(list(NA), 10)
    lambda <- rep(list(NA), 10)
    warning("Entire time series is uniform. NAs produced")
  }
  else {
    if (isTRUE(scale)) {
      data[, 2] <- c(scale(data[, 2]))
    }
    best_smap <- tryCatch(
      rEDM::PredictNonlinear(
        dataFrame = data,
        lib = c(1, NROW(data)), pred = c(1, NROW(data)),
        columns = names(data)[2], target = names(data)[2],
        E = E, tau = -tau, theta = theta_seq, knn = 0, verbose = FALSE,
        showPlot = FALSE),
      error = function(err) {
        warning("Long period of unchanging values. uniJI not calculated for node")
      })
    if (inherits(best_smap, "character")) {
      smap_results <- rep(list(NA), 10)
      lambda <- rep(list(NA), 10)
    }
    else {
      best <- order(-best_smap$rho)[1]
      theta <- theta_seq[best]
      smap_results <- uni_smap_jacobian_est(ts = data,
                                            theta = theta, E = E, tau = tau)
      smap_avg <- Reduce("+", smap_results)/length(smap_results)
      eig <- eigen(smap_avg)$values
      lambda <- eig[order(abs(eig))[E]]
    }
  }
  return(list(smapJ = smap_results, eigenJ = mean(abs(unlist(lambda))),
              reJ = mean(Re(unlist(lambda))), imJ = mean(Im(unlist(lambda)))))
}


#' ...
#'
#' ...
#'
#' @param ts ...
#' @param E Integer. Embedding dimension for state-space reconstruction.
#' @param tau Integer. Time lag for state-space reconstruction.
#' @param theta ...
#'
#' @return ...

uni_smap_jacobian_est <- function(ts, E, tau, theta) {

  smap_best <- rEDM::SMap(
    dataFrame = ts, E = E, tau = tau,
    theta = theta, lib = c(1, NROW(ts)), pred = c(1, NROW(ts)),
    knn = 0, columns = names(ts)[2], target = names(ts)[2],
    verbose = FALSE)

  smap_coef <- smap_best$coefficients

  jac <- lapply(2:NROW(smap_coef), function(k) {
    if (!is.na(smap_coef[k, 2])) {
      M <- rbind(as.numeric(smap_coef[k, 3:(2 + E)]),
                 cbind(diag(E - 1), rep(0, E - 1)))

    } else {
      M <- NA
    }
    return(M)
  })

  return(jac)
}

#' Calculate Theil Sen trend
#'
#' @param x A numeric vector representing the time series.
#'
#' @return slope value

theil_sen <- function(x) {
  n <- length(x)
  if(n < 2) stop("At least two data points are required.")
  
  idx <- combn(n, 2)
  
  slopes <- (x[idx[2, ]] - x[idx[1, ]]) / (idx[2, ] - idx[1, ])
  
  slope <- median(slopes)
  
  return(slope)
}

#' Calculate Kurtosis
#'
#' @param x A numeric vector representing the time series.
#'
#' @return kurtosis value

kurtosis <- function(x, na.rm = TRUE) {
  if (na.rm) x <- x[!is.na(x)]
  n <- length(x)
  m <- mean(x)
  s <- sd(x)
  
  if(s == 0|n < 4){kurt<-NA}
  else{
    kurt <- (n * (n + 1) * sum((x - m)^4) / (s^4)) / ((n - 1) * (n - 2) * (n - 3)) - (3 * (n - 1)^2) / ((n - 2) * (n - 3))
  }
  
  return(kurt)
}

#' Calculate Disparity Index
#'
#' Computes the disparity index for a numeric time series.
#'
#' @param x A numeric vector representing the time series.
#' @param na_rm Logical. If `TRUE`, removes `NA` values before calculation.
#' @param as_df Logical. If `TRUE`, returns a tibble with the disparity index.
#'
#' @return Either a numeric value or a tibble, depending on `as_df`.
#'
#' @references Fernández-Martínez M., Vicca S., Janssens I.A., Carnicer J., Martín-Vide J., Peñuelas J. (2018) 'The consecutive disparity index, D: a measure of temporal variability in ecological studies'. Ecosphere 9(12), e02527.

disparity_index <- function(x, na_rm = TRUE, as_df = TRUE) {

  if (na_rm) {
    x <- na.omit(x)
  }

  if (length(x) == 1) {
    di <- 0

  } else {
    fractions <- (x[2:length(x)] + 1)/(x[1:length(x) - 1] + 1)
    di <- 1/(length(x) - 1) * sum(abs(log(fractions)))
  }

  if (as_df) {
    return(tibble::tibble(disparity_index = di))

  } else {
    return(di)
  }

}


#' Calculate Skewness
#'
#' Computes skewness for a numeric vector, matrix, or data frame.
#'
#' @param x A numeric vector, matrix, or data frame.
#' @param na.rm Logical. If `TRUE`, removes `NA` values before calculation.
#'
#' @return A numeric value for skewness or a vector/matrix of skewness values.

skewness <- function(x, na.rm = FALSE) {
  if (is.matrix(x))
    apply(x, 2, skewness, na.rm = na.rm)
  else if (is.vector(x)) {
    if (na.rm)
      x <- x[!is.na(x)]
    n <- length(x)
    (sum((x - mean(x))^3)/n)/(sum((x - mean(x))^2)/n)^(3/2)
  }
  else if (is.data.frame(x))
    sapply(x, skewness, na.rm = na.rm)
  else skewness(as.vector(x), na.rm = na.rm)
}


#' Perform Statistical Grouping on Metrics
#'
#' Performs pairwise Wilcoxon tests and generates grouping labels for metrics.
#'
#' @param x A data frame containing the metrics and grouping variable.
#' @param y A character vector of metric column names.
#' @param z A character string representing the grouping variable column name.
#'
#' @return The input data frame with added columns for grouping and labels.

stats_grouping <- function(x, y, z) {

  for (metric in y) {


    test <- pairwise.wilcox.test(as.numeric(as.matrix(x[metric])),
                                 as.character(as.matrix(x[z])),
                                 p.adjust.method = "bonferroni",
                                 paired = FALSE)

    test$p.value <- rbind(rep(NA, ncol(test$p.value)), test$p.value)
    rownames(test$p.value)[1] <- colnames(test$p.value)[1]
    test$p.value <- cbind(test$p.value, rep(NA, nrow(test$p.value)))
    colnames(test$p.value)[ncol(test$p.value)] <- rownames(test$p.value)[nrow(test$p.value)]

    temp <- multcompLetters(test$p.value,)
    x[paste0("test.group.",metric)] <- as.vector(temp$Letters[as.character(as.matrix(x[z]))])

    x[paste0("labels.",metric)] <- rep(paste0(noquote(temp$Letters), collapse = " | "), nrow(x))

  }
  x

}


#' Summarize Early Warning Signals
#'
#' Summarizes early warning signals for time series data.
#'
#' @param data A data frame containing metrics and trajectory information.
#' @param group A character string indicating the grouping variable for statistical comparisons
#' (e.g., `class` or `condition`).
#' @param metrics A character vector of metrics to include in the plot.
#'
#' @return A summarized data frame with grouped metrics.

sort_ews <- function(data, group, metrics){
  
  data <- data %>% group_by(ID) %>% mutate(ts.length = length(x))
  if (group %in% colnames(data)) {
    out <- data %>%
      group_by(ID) %>%
      summarise(across(all_of(c(group, "ts.length", metrics)), ~unique(.x)))
    out
    
  } else {
    out <- data %>%
      group_by(ID) %>%
      summarise(across(all_of(c("ts.length", metrics)), ~unique(.x)))
    out
  }
  
}

sort_ews_simu <- function(data, group, metrics){
  
  data <- data %>% group_by(ID) %>% mutate(ts.length = length(x))
  if (group %in% colnames(data)) {
    out <- data %>%
      group_by(ID) %>%
      summarise(across(all_of(c(group, "ts.length", "sr", metrics)), ~unique(.x)))
    out
    
  } else {
    out <- data %>%
      group_by(ID) %>%
      summarise(across(all_of(c("ts.length", "sr", metrics)), ~unique(.x)))
    out
  }
  
}


#' Normalize Time Series
#'
#' Normalizes a time series using different methods.
#'
#' @param x A numeric vector representing the time series.
#' @param type A character string specifying the normalization method: `"z-score"`, `"unity"`, or `"rank"`.
#'
#' @return A normalized numeric vector.

norm_ts <- function(x, type){
  if (type=="z-score") {
    x <- scale(x)
  }
  else if(type=="unity"){
    x <- (x-min(x, na.rm = T))/(max(x, na.rm = T)-min(x, na.rm = T))
  }
  else if(type=="rank"){
    x <- rank(x)/length(x)
  }
  else{
    cat("norm how?")
  }
  return(x)
}


#' Calculate Rolling Metrics
#'
#' Computes rolling metrics (e.g., mean, CV, disparity) for a time series.
#'
#' @param x A numeric vector representing the time series.
#' @param winsize Numeric. The rolling window size as a percentage of the total series length.
#'
#' @return A data frame with rolling metrics and their Kendall correlations.

calc_roll_metrics <- function(x, winsize=50) {

  num <- 1:round(length(x)*winsize/100)
  res <- data.frame(mean = rep(NA, length(x)-length(num)),
                    CV = rep(NA, length(x)-length(num)),
                    disparity = rep(NA, length(x)-length(num)),
                    dispersion = rep(NA, length(x)-length(num)),
                    SD = rep(NA, length(x)-length(num)),
                    skew = rep(NA, length(x)-length(num)),
                    ar1 = rep(NA, length(x)-length(num)),
                    kurtosis = rep(NA, length(x)-length(num)))
  out <- data.frame(mean.tau = NA)
  i <- 1

  while(max(num)<length(x)){
    res$disparity[i] <- disparity_index(
      norm_ts(x[num], type = "unity")+
        0.01*mean(norm_ts(x[num], type = "unity")))$disparity_index
    res$mean[i] <- mean(x[num])
    res$CV[i] <- sd(x[num])/res$mean[i]
    res$dispersion[i] <- sd(x[num])*res$CV[i]
    res$SD[i] <- sd(x[num])
    res$skew[i] <- sd(x[num])/res$mean[i]
    res$ar1[i] <- acf(x[num], plot = FALSE, lag.max = 1)$acf[2]
    res$kurtosis[i] <- kurtosis(x[num])

    num <- num + 1
    i <- i + 1
  }

  out$mean.tau <- cor(1:nrow(res), res$mean,method = "kendall")
  out$CV.tau <- cor(1:nrow(res), res$CV, method = "kendall")
  out$disparity.tau <- cor(1:nrow(res), res$disparity, method = "kendall")
  out$dispersion.tau <- cor(1:nrow(res), res$dispersion, method = "kendall")
  out$skew.tau <- cor(1:nrow(res), res$skew, method = "kendall")
  out$SD.tau <- cor(1:nrow(res), res$SD, method = "kendall")
  out$ar1.tau <- cor(1:nrow(res), res$ar1, method = "kendall")
  out$kurtosis.tau <- cor(1:nrow(res), res$kurtosis, method = "kendall")

  out
}


#' Plot Dynamical Footprint
#'
#' Generates visualizations for time series data, including detrended series and metrics.
#'
#' @param data A list of data frames with time series data.
#' @param idts An identifier for the time series to plot.
#' @param metrics A character vector of metrics to include in the plot.
#' @param filepath A character string specifying the output file path for the plot.
#' @param detrend.type A character string specifying the detrending method.
#' @param group A character string indicating the grouping variable for statistical comparisons
#' (e.g., `class` or `condition`).
#'
#' @return A ggplot object or a saved plot.

plot_dynamical_footprint <- function(data, idts, metrics, filepath,
                                     detrend.type, group) {

  facet_labels <- c(full = "metric", roll = "metric trend (Kendall's tau)")
  ploties.ts <- list()

  temp <- do.call(rbind, data) %>% dplyr::filter(ID == idts)

  if (detrend.type!="none") {
    p1 <- ggplot() +
      geom_line(data = temp, aes(x = x, y = y), linewidth = 1.5) +  # Thicker first line
      geom_line(data = temp, aes(x = x, y = y_model),
                linetype = "dashed", color = "red", linewidth = 1.5) +  # Thicker, red dashed second line
      theme_minimal() + labs(y = "variable", x = "time")

  } else {
    p1 <- ggplot() +
      geom_line(data = temp, aes(x = x, y = y), linewidth = 1.5) +
      theme_minimal() + labs(y = "variable", x = "time")
  }
  p2 <- ggplot(data=temp, aes(x=x, xend=x, y=0, yend=y_res)) +
    geom_segment(linewidth = 1.5) + ylab("residuals") + xlab("time") +
    theme_minimal()

  df = sort_ews(do.call(rbind, data), group, metrics=metrics)

  df_long1 <- df %>%
    # Pivot the data into long format
    pivot_longer(cols = all_of(metrics),
                 names_to = "metric",
                 values_to = "value") %>%
    # Calculate percentile rank for "full" metrics
    mutate(
      value = ifelse(str_detect(metric, "full"),
                     percent_rank(value),
                     value),
      category = ifelse(str_detect(metric, "\\.full$"), "full", "roll"),
      metric = str_replace(metric, "\\.full$", "") %>%
        str_replace("\\.roll$", ".tau")
    ) %>%
    filter(ID == idts)

  df_long2 <- df %>%
    group_by(get(group)) %>%
    mutate(
      across(
        .cols = all_of(metrics),
        .fns = percent_rank,
        .names = "{.col}.rank"
      )
    ) %>%
    melt(measure.vars = paste0(metrics,".rank"),
         variable.name = "metric.rank", value.name = "percentil_rank") %>%
    filter(ID == idts) %>%
    dplyr::select(metric.rank, percentil_rank)

  df_long = cbind(df_long1, df_long2)

  if(sum(df$class==df$class[df$ID==idts])<2){
    df_long = df_long %>%
      mutate(percentil_rank = rep(0.5, length(df_long2$metric.rank)))
  }

  p3 = ggplot(df_long, aes(x = metric, y = value, fill = percentil_rank)) +
    geom_col(width = 1, na.rm = TRUE) +
    scale_fill_stepsn(
      colours = viridis(100, option = "H"),
      breaks = c(0.05, 0.25, 0.75, 0.95),
      labels = c(".05", ".25", ".75", ".95"),
      limits = c(0, 1)
    ) +
    labs(fill = "class rank") +
    theme_minimal() +
    theme(
      legend.position = "bottom",
      legend.direction = "horizontal",
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      axis.ticks = element_blank(),
      axis.text.x = element_text(size = 11, face = "bold"),
      axis.text.y = element_text(size = 11, face = "bold")
    ) +
    coord_flip() +
    facet_wrap(~category, scales = "free_y", ncol = 1,
               labeller = labeller(category = facet_labels)) +
    ylim(-1,1)

  ploties.ts <- plot_grid(p1, p2, p3, labels = "AUTO", ncol = 3)

  save_plot(filename = paste0(filepath, "/figures/", idts, ".pdf"),
            ploties.ts, ncol = 3, base_asp = 1.1)

}


#' Run Dynamical Footprint Analysis
#'
#' This function processes input time series data to calculate dynamical footprint metrics.
#' Optionally, detrending and cutting can be applied before computing metrics.
#' It can save diagnostic plots for each dataset.
#'
#' @param data A list of time series datasets to analyze.
#' @param metrics.type A character string specifying the type of metrics to calculate. Default is "all".
#' @param detrend.type A character string specifying the detrending method. Options are "none", "linear", etc. Default is "none".
#' @param group A character string indicating the grouping variable for statistical comparisons
#' (e.g., `class` or `condition`).
#' @param cut Logical, whether to cut the data. Default is \code{TRUE}.
#' @param cores Integer, number of cores for parallel processing. Default is 1.
#' @param saveplots Logical, whether to save plots of the results. Default is \code{FALSE}.
#' @param filepath A string specifying the directory to save plots. Default is the current working directory.
#'
#' @return A list of datasets with calculated dynamical footprint metrics.
#' @import parallel
#' @import dplyr
#' @import tidyr
#' @import ggplot2
#' @import stringr
#' @import stringr
#' @importFrom reshape2 melt
#' @importFrom cowplot plot_grid
#' @importFrom viridis scale_fill_viridis
#'
#' @examples
#' data(fishbiomass)
#' data(fishbiomass_classif)
#'
#' data <- fishbiomass |>
#'   dplyr::left_join(fishbiomass_classif$traj_ts_full |>
#'                      dplyr::select(simu_id, class, traj, trend, loc_brk_chg),
#'                    by=c("stockid"="simu_id"))
#'
#' data_list <- data |>
#'   dplyr::rename(x=year, y=TBbest) |>
#'   dplyr::group_by(stockid) |>
#'   dplyr::group_split() |>
#'   stats::setNames(unique(data$stockid))
#'
#' dynfoot <- run_dynfoot(
#'   data=data_list, metrics.type="all", detrend.type="gaussian",
#'   group="class", cut=TRUE, cores = 1,
#'   saveplots = FALSE, filepath=getwd())
#'
#' @export

run_dynfoot <- function(data, metrics.type="all", detrend.type="none",
                        group="class", cut=TRUE, min.length = 20, cores=1,
                        saveplots=FALSE, filepath=getwd()){

  det.data <- parallel::mclapply(data, detandcut, dettype = detrend.type,
                                 cut = cut, mc.cores = cores)

  data <- parallel::mclapply(det.data[sapply(det.data, nrow) >= min.length], calc_metrics, mc.cores = cores)

  if (saveplots) {

    for (i in 1:length(names(data))) {
      plot_dynamical_footprint(
        data, idts = names(data)[i], metrics = metrics,
        filepath = filepath, detrend.type = detrend.type, group = group)
    }

  }

  return(data)

}


#' Dynamical Footprint Summary and PCA Visualization
#'
#' This function generates summary visualizations for dynamical footprint metrics
#' using boxplots grouped by a specified factor and provides PCA plots for detailed analysis.
#' It supports filtering by minimum time series length, normalizing metrics, and
#' handling grouped or ungrouped data.
#'
#' @param data A list of datasets containing dynamical footprint metrics.
#' Each dataset should include a unique identifier (`ID`), a grouping variable (e.g., `class`),
#' and the metrics to analyze.
#' @param metrics A character vector specifying the names of metrics to analyze.
#' The metrics can include "full" or "rolling" metrics for comparison.
#' @param group A character string indicating the grouping variable for statistical comparisons
#' (e.g., `class` or `condition`).
#' @param min.length An integer specifying the minimum required length of time series to include
#' in the analysis. Default is \code{40}.
#'
#' @return A list with two elements:
#' \itemize{
#'   \item \code{box_plot}: A combined \code{ggplot2} object showing boxplots of specified metrics grouped by the factor.
#'   \item \code{PCA}: A combined \code{ggplot2} object visualizing the PCA of "full" and "trend" metrics.
#' }
#'
#' @import dplyr
#' @import ggplot2
#' @importFrom reshape2 melt
#' @importFrom cowplot plot_grid
#' @importFrom viridis scale_fill_viridis
#' @importFrom FactoMineR PCA
#' @importFrom factoextra fviz_pca_var
#' @importFrom missMDA imputePCA
#' @importFrom multcompView multcompLetters
#' @export

dynfoot_summary_plot <- function(data, metrics, group, min.length=40) {

  data <- do.call(rbind, data)

  if (group %in% colnames(data)) {

    data <- sort_ews(data, group, metrics)

    data <- data %>% filter(ts.length >= min.length)

    metrics.norm <- metrics[str_detect(metrics, "full")]
    data[metrics.norm] <- lapply(data[metrics.norm], norm_ts, type="rank")

    data <- stats_grouping(data, metrics, group)

    names(data)[names(data) == group] <- "clase"

    ploties.ews <- list()
    metrics.full <- metrics[str_detect(metrics, "full")]

    temp <- data

    temp<- temp %>% dplyr::add_count(clase) %>%
      dplyr::mutate(clase = paste0(clase, ' (', n, ')')) %>%
      melt(measure.vars = metrics.full, variable.name = "metric")

    temp$labels <- as.character(temp[1,paste0("labels.", temp$metric)])

    p1 <- ggplot(temp, aes(x = metric, y = value, fill = clase)) +
      geom_boxplot(outlier.shape = NA, alpha = 0.8, na.rm = TRUE, position = position_dodge()) +
      geom_point(na.rm = TRUE, position = position_jitterdodge(0.05), pch=21) +
      labs(x="metric", y="value") +
      theme(axis.text = element_text(size = 10)) +
      theme(axis.title = element_text(size = 10)) +
      theme(.inside = "right") +
      theme_light() +
      scale_fill_viridis(discrete = TRUE, option = "H") +
      geom_text(aes(x=metric, y=1.05, label=labels, fontface = "bold"), check_overlap = TRUE) +
      labs(fill = 'class (# obs)')

    ploties.ews <- c(ploties.ews, list(p1))

    metrics.full <- metrics[str_detect(metrics,"roll")]

    temp <- data
    temp <- temp %>% dplyr::add_count(clase) %>%
      dplyr::mutate(clase = paste0(clase, ' (', n, ')')) %>%
      melt(measure.vars = metrics.full, variable.name = "metric")
    temp$labels <- as.character(temp[1,paste0("labels.", temp$metric)])

    p1 <- ggplot(temp, aes(x = metric, y = value, fill = clase)) +
      geom_boxplot(outlier.shape = NA, alpha = 0.8, na.rm = TRUE, position = position_dodge()) +
      geom_point(na.rm = TRUE, position = position_jitterdodge(0.05), pch=21) +
      labs(x="metric", y="value") +
      theme(axis.text = element_text(size = 10)) +
      theme(axis.title = element_text(size = 10)) +
      theme(.inside = "right") +
      theme_light() +
      scale_fill_viridis(discrete = TRUE, option = "H") +
      geom_text(aes(x=metric, y=1.05, label=labels, fontface = "bold"), check_overlap = TRUE) +
      labs(fill = 'class (# obs)')

    ploties.ews <- c(ploties.ews, list(p1))

    ploties.ews <- plot_grid(plotlist = ploties.ews, nrow = 2)

  } else {

    message("valid group needed to make statistical comparisons")

    data <- data %>% dplyr::group_by(ID) %>%
      dplyr::mutate(ts.length = length(x)) %>%
      dplyr::filter(ts.length >= min.length)

    data <- sort_ews(data, group, metrics)

    metrics.norm <- metrics[str_detect(metrics,"full")]
    data[metrics.norm] <- lapply(data[metrics.norm], norm_ts, type="rank")

    ploties.ews <- list()
    metrics.full <- metrics[str_detect(metrics, "full")]

    temp <- data

    temp<- temp %>% melt(measure.vars = metrics.full,variable.name = "metric")

    p1 <- ggplot(temp, aes(x = metric, y = value, fill = metric)) +
      geom_boxplot(outlier.shape = NA, alpha = 0.8, na.rm = TRUE, position = position_dodge()) +
      geom_point(na.rm = TRUE, position = position_jitterdodge(0.05), pch=21) +
      labs(x="metric", y="value") +
      theme(axis.text = element_text(size = 10)) +
      theme(axis.title = element_text(size = 10)) +
      theme_light() +
      scale_fill_viridis(discrete = TRUE, option = "H")

    ploties.ews <- c(ploties.ews, list(p1))

    metrics.full <- metrics[str_detect(metrics, "roll")]
    temp <- data
    temp<- temp %>% melt(measure.vars = metrics.full, variable.name = "metric")

    p1 <- ggplot(temp, aes(x = metric, y = value, fill = metric)) +
      geom_boxplot(outlier.shape = NA, alpha = 0.8, na.rm = TRUE, position = position_dodge()) +
      geom_point(na.rm = TRUE, position = position_jitterdodge(0.05), pch=21) +
      labs(x="metric", y="value") +
      theme(axis.text = element_text(size = 10)) +
      theme(axis.title = element_text(size = 10)) +
      theme_light() +
      scale_fill_viridis(discrete = TRUE, option = "H")

    ploties.ews <- c(ploties.ews, list(p1))

    ploties.ews <- plot_grid(plotlist = ploties.ews, nrow = 2)

    return(ploties.ews)

  }

  ploties <- list()

  metrics.full = metrics[str_detect(metrics,"full")]

  res.comp <- data[metrics.full] %>% drop_na()

  pca.out <- PCA(res.comp, graph = FALSE)

  p1 = fviz_pca_var(pca.out, col.var = "cos2",
                    gradient.cols = c("black", "blue", "green"),
                    repel = TRUE)

  ploties <- c(ploties, list(p1))

  cormat <- cor(data[metrics.full], use = "complete.obs", method = "kendall")

  get_upper_tri <- function(cormat){
    cormat[upper.tri(cormat)] <- NA
    return(cormat)
  }

  melted_cormat <- melt(get_upper_tri(cormat), na.rm = TRUE)

  reorder_cormat <- function(cormat){
    dd <- as.dist((1-cormat)/2)
    hc <- hclust(dd)
    cormat <- cormat[hc$order, hc$order]
  }

  cormat <- reorder_cormat(cormat)
  upper_tri <- get_upper_tri(cormat)

  melted_cormat <- melt(upper_tri, na.rm = TRUE)

  p1 <- ggplot(data = melted_cormat %>% dplyr::filter(Var1 != Var2),
               aes(Var1, Var2, fill = value)) +
    geom_tile(color = "white") +
    scale_y_discrete(position = "right") +
    scale_fill_viridis(option = "B", name="kendall correlation") +
    theme_minimal() +
    theme(
      axis.text.x = element_text(angle = 45, vjust = 1, size = 10, hjust = 1),
      axis.text.y = element_text(angle = 0, vjust = 0.5, size = 10, hjust = 1),
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.5, 0.7),
      legend.direction = "horizontal"
    ) +
    coord_fixed() +
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))

  ploties <- c(ploties, list(p1))

  metrics.roll = metrics[str_detect(metrics, "roll")]

  res.comp <- data[metrics.roll] %>% drop_na()

  pca.out <- PCA(res.comp, graph = FALSE)

  p1 = fviz_pca_var(pca.out, col.var = "cos2",
                    gradient.cols = c("black", "blue", "green"),
                    repel = TRUE)

  ploties <- c(ploties, list(p1))

  cormat=cor(data[metrics.roll], use = "complete.obs", method = "kendall")

  get_upper_tri <- function(cormat){
    cormat[upper.tri(cormat)] <- NA
    return(cormat)
  }

  melted_cormat <- melt(get_upper_tri(cormat), na.rm = TRUE)

  reorder_cormat <- function(cormat){
    dd <- as.dist((1-cormat)/2)
    hc <- hclust(dd)
    cormat <- cormat[hc$order, hc$order]
  }

  cormat <- reorder_cormat(cormat)
  upper_tri <- get_upper_tri(cormat)

  melted_cormat <- melt(upper_tri, na.rm = TRUE)

  p1 <- ggplot(data = melted_cormat %>% dplyr::filter(Var1 != Var2),
               aes(Var1, Var2, fill = value)) +
    geom_tile(color = "white") +
    scale_y_discrete(position = "right") +
    scale_fill_viridis(option = "B",name="kendall correlation") +
    theme_minimal() +
    theme(
      axis.text.x = element_text(angle = 45, vjust = 1, size = 10, hjust = 1),
      axis.text.y = element_text(angle = 0, vjust = 0.5, size = 10, hjust = 1),
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.5, 0.7),
      legend.direction = "horizontal"
    ) +
    coord_fixed() +
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))

  ploties <- c(ploties, list(p1))

  ploties <- plot_grid(plotlist = ploties, nrow = 2)

  return(list(box_plot = ploties.ews, PCAcorr = ploties))

}


#' Boosted Regression Trees Model with Leave-One-Out Cross-Validation (LOOCV)
#'
#' This function trains a boosted regression tree (BRT) model using the `xgboost` algorithm
#' and evaluates it through Leave-One-Out Cross-Validation (LOOCV). It outputs predictions
#' and probabilities for each observation in the dataset.
#' # Example usage:
#' "result <- run_ml_model(data = my_data, target = "class", predictors = c("var1", "var2"))"
#'
#' @param data A data frame containing the dataset, including predictors, target, and an "ID" column.
#' @param target A character string specifying the name of the target variable (default: "class").
#' @param predictors A vector of character strings specifying the predictor variable names.
#' @param nrounds Number of boosting rounds.
#' @param max_depth Maximum depth of trees.
#' @param eta Learning rate.
#' @param gamma Minimum loss reduction to make a split.
#' @param colsample_bytree Subsample ratio of columns when constructing trees.
#' @param min_child_weight Minimum sum of instance weights needed in a child node.
#' @param subsample Subsample ratio of training instances.
#'
#' @return A data frame combining the original dataset with predicted probabilities,
#'         predicted classes, and maximum probabilities for each observation.
#'
#' @export

run_ml_model <- function(data, target="class", predictors=metrics,
                         nrounds=300, max_depth=5, eta=0.01, gamma=0,
                         colsample_bytree=1.0, min_child_weight=1,
                         subsample=1.0) {

  # Backup the full dataset for later use
  full.data <- data

  # Prepare the data by selecting predictors, ID, and target columns and removing rows with NA values
  data <- data[c(predictors, "ID", target)] %>% drop_na()

  # Ensure the target variable is a factor (required for classification tasks)
  data[[target]] <- as.factor(data[[target]])

  # Define the predictor matrix (X) using one-hot encoding and exclude the intercept
  X <- model.matrix(~ . - 1, data = data[, predictors])

  # Extract the target vector (y)
  y <- data[[target]]

  # Initialize a list to store predicted probabilities for each observation during LOOCV
  prob_list <- vector("list", nrow(X))

  # Define hyperparameters for xgboost training
  xgb_grid <- expand.grid(
    nrounds = nrounds,        # Number of boosting rounds
    max_depth = max_depth,        # Maximum depth of trees
    eta = eta,           # Learning rate
    gamma = gamma,            # Minimum loss reduction to make a split
    colsample_bytree = colsample_bytree, # Subsample ratio of columns when constructing trees
    min_child_weight = min_child_weight, # Minimum sum of instance weights needed in a child node
    subsample = subsample       # Subsample ratio of training instances
  )

  # Perform Leave-One-Out Cross-Validation (LOOCV)
  for (i in seq_len(nrow(X))) {
    # Split data: one observation as test set, remaining as training set
    X_train <- X[-i, , drop = FALSE]
    y_train <- y[-i]
    X_test <- X[i, , drop = FALSE]

    # Train an xgboost model on the training set
    xgb_model <- train(
      X_train, y_train,
      method = "xgbTree",                     # Use xgboost's tree-based model
      trControl = trainControl(method = "none"), # No internal resampling within LOOCV
      tuneGrid = xgb_grid                     # Use predefined hyperparameters
    )

    # Predict probabilities for the left-out test observation
    prob_list[[i]] <- predict(xgb_model, X_test, type = "prob")
  }

  # Combine all predicted probabilities into a single data frame
  prob_df <- do.call(rbind, prob_list)

  # Calculate maximum probability and predicted class for each sample
  prob_df$MaxProbability <- apply(prob_df[, seq_along(unique(full.data[[target]]))], 1, max)

  prob_df$Predictedclass <- apply(prob_df[, seq_along(unique(full.data[[target]]))], 1, which.max)

  prob_df$Predictedclass <- names(prob_df)[prob_df$Predictedclass]

  prob_df$ID <- data$ID

  # Merge original dataset with prediction results based on ID column
  return(merge(full.data, prob_df, by="ID"))
}


#' Confusion Matrix Plot with Sensitivities
#'
#' This function creates a confusion matrix plot using `ggplot2`, where the relative frequencies
#' of predictions are visualized with a Viridis color palette. Sensitivity values for each class
#' are also annotated on the plot.
#'
#' @param data A data frame containing the actual class (`class`) and predicted class (`Predictedclass`).
#'
#' @return A ggplot object displaying the confusion matrix with annotations.

conf.matrix.plot <- function(data) {

  # Define the desired order of class levels
  desired_order <- c("abrupt", "linear", "no_change", "quadratic")

  # Create a confusion matrix from actual and predicted classes
  cm <- table(data$class, data$Predictedclass)

  # Convert confusion matrix to a data frame for plotting
  cm_df <- as.data.frame(cm)

  # Ensure factor levels for rows (Var1) and columns (Var2) match the desired order
  cm_df$Var1 <- factor(cm_df$Var1, levels = desired_order)
  cm_df$Var2 <- factor(cm_df$Var2, levels = desired_order)

  # Normalize frequencies within each row (actual class) to calculate relative frequencies
  cm_df <- cm_df %>%
    group_by(Var1) %>%
    mutate(RelativeFreq = Freq / sum(Freq))

  # Create a discrete Viridis color palette for each class
  n_cols <- length(unique(cm_df$Var1))  # Number of unique classes
  viridis_palette <- viridis(n_cols, option = "H")  # Generate Viridis colors

  # Assign colors to each class based on column order
  cm_df <- cm_df %>%
    mutate(Color = viridis_palette[as.numeric(as.factor(Var1))])

  # Calculate sensitivities (true positive rate) for each class
  actual_totals <- rowSums(cm[desired_order, desired_order])  # Total actual occurrences per class
  true_positives <- diag(cm[desired_order, desired_order])   # True positives per class
  sensitivities <- true_positives / actual_totals

  # Create a data frame for sensitivity annotations
  sensitivity_labels <- data.frame(
    Class = factor(desired_order, levels = desired_order),
    Sensitivity = sprintf("%.2f", sensitivities)  # Format sensitivities to two decimal places
  )

  # Generate the confusion matrix plot using ggplot2
  ggplot(data = cm_df, mapping = aes(x = Var1, y = Var2)) +
    geom_tile(aes(fill = Color, alpha = RelativeFreq), color = "white") +  # Tiles with color and transparency based on RelativeFreq
    ylab("predicted shape class") + xlab("actual shape class") +
    geom_text(aes(label = sprintf("%1.0f", Freq)), vjust = 1) +            # Add frequency text to tiles
    scale_fill_identity() +                                               # Use fixed colors from Viridis palette
    scale_alpha(range = c(0.5, 1)) +                                      # Adjust transparency range
    theme_minimal() +
    theme(
      legend.position = "none",                                           # Remove legend
      panel.grid = element_blank()                                        # Remove grid lines
    ) +
    geom_text(data = sensitivity_labels, aes(x = Class, y = ncol(cm) + 0.6, label = Sensitivity),
              inherit.aes = FALSE, size = 4, fontface = "bold") +         # Annotate sensitivities above columns
    coord_cartesian(ylim = c(1, ncol(cm) + 0.1))                          # Extend y-axis to fit sensitivity labels

}


#' Violin Plot of Classification Probabilities by Predicted Class
#'
#' This function generates a violin plot showing the distribution of maximum classification
#' probabilities for each predicted class. It also overlays jittered points representing individual
#' samples with their actual classes.
#'
#' @param data A data frame containing `Predictedclass`, `MaxProbability`, and `class` columns.
#'
#' @return A ggplot object displaying the violin plot with jittered points.

violin.prob.plot <- function(data) {

  # Define the desired order of class levels for plotting
  desired_order <- c("abrupt", "linear", "no_change", "quadratic")

  # Set factor levels for predicted and actual classes to ensure consistent ordering in the plot
  data$Predictedclass <- factor(data$Predictedclass, levels = desired_order)
  data$class <- factor(data$class, levels = desired_order)

  # Generate the violin plot using ggplot2
  ggplot(data, aes(x = Predictedclass, y = MaxProbability)) +
    geom_violin(aes(fill = Predictedclass), trim = TRUE, alpha = 0.5) +   # Violin plots with transparency
    geom_jitter(aes(color = class), width = 0.2, alpha = 0.7) +           # Jittered points for individual samples
    theme_minimal() +
    ylab("classification probability") +
    xlab("predicted shape class") +
    theme(legend.position = "none") +                                     # Remove legend for simplicity
    scale_fill_viridis(option = "H", discrete = TRUE) +                   # Use Viridis color palette for fill colors
    scale_color_viridis(option = "H", discrete = TRUE) +                  # Use Viridis palette for point colors
    scale_size_continuous(range = c(1, 3)) +                              # Adjust point sizes if needed
    geom_hline(yintercept = 0.25, linetype = "dashed", color = "black") + # Add a reference line at probability threshold (e.g., random chance)
    coord_cartesian(ylim = c(0, 1))                                       # Limit y-axis to [0,1] range

}










run_ml_model <- function(data, target="class", predictors=metrics, nrounds=500, max_depth=5, eta=0.01, gamma=0, colsample_bytree=1.0, min_child_weight=1, subsample=1.0, train="LOO", trainsetsize=0.8) {
  
  data = sort_ews(data = do.call(rbind,data),group = target,metrics = predictors) %>% rename(id = ID) %>% filter(ts.length>19)
  
  # Backup the full dataset for later use
  full.data <- data
  
  # Prepare the data by selecting predictors, ID, and target columns and removing rows with NA values
  data <- data[c(predictors, "id", target)] %>% drop_na()
  
  # Ensure the target variable is a factor (required for classification tasks)
  data[[target]] <- as.factor(data[[target]])
  
  # Define the predictor matrix (X) using one-hot encoding and exclude the intercept
  X <- model.matrix(~ . - 1, data = data[, predictors])
  
  # Extract the target vector (y)
  y <- data[[target]]
  
  # Initialize a list to store predicted probabilities for each observation
  prob_list <- vector("list", nrow(X))
  
  # Define hyperparameters for xgboost training
  xgb_grid <- expand.grid(
    nrounds = nrounds,
    max_depth = max_depth,
    eta = eta,
    gamma = gamma,
    colsample_bytree = colsample_bytree,
    min_child_weight = min_child_weight,
    subsample = subsample
  )
  
  # Training method selection
  if(train == "LOO") {
    # Perform Leave-One-Out Cross-Validation (LOOCV)
    for (i in seq_len(nrow(X))) {
      X_train <- X[-i, , drop = FALSE]
      y_train <- y[-i]
      X_test <- X[i, , drop = FALSE]
      
      # Train an xgboost model on the training set
      xgb_model <- caret::train(
        X_train, y_train,
        method = "xgbTree",
        trControl = caret::trainControl(method = "none"),
        tuneGrid = xgb_grid
      )
      
      # Predict probabilities for the left-out test observation
      prob_list[[i]] <- predict(xgb_model, X_test, type = "prob")
    }
  } else if(train == "subset") {
    # Train on a subset of the data
    set.seed(123)  # for reproducibility
    train_indices <- sample(seq_len(nrow(X)), size = floor(trainsetsize * nrow(X)))
    X_train <- X[train_indices, , drop = FALSE]
    y_train <- y[train_indices]
    X_test <- X[-train_indices, , drop = FALSE]
    
    # Train the model on the subset
    xgb_model <- caret::train(
      X_train, y_train,
      method = "xgbTree",
      trControl = caret::trainControl(method = "none"),
      tuneGrid = xgb_grid
    )
    
    # Predict probabilities for the remaining data
    for (i in seq_len(nrow(X_test))) {
      prob_list[[i]] <- predict(xgb_model, X_test[i, , drop = FALSE], type = "prob")
    }
  }
  
  # Combine all predicted probabilities into a single data frame
  prob_df <- do.call(rbind, prob_list)
  
  # Calculate maximum probability and predicted class for each sample
  prob_df$MaxProbability <- apply(prob_df[, seq_along(unique(full.data[[target]]))], 1, max)
  prob_df$Predictedclass <- apply(prob_df[, seq_along(unique(full.data[[target]]))], 1, which.max)
  prob_df$Predictedclass <- names(prob_df)[prob_df$Predictedclass]
  prob_df$id <- if(train == "LOO") data$id else data$id[-train_indices]
  
  output.data = merge(full.data, prob_df, by="id")
  
  # Train model for feature importance
  if(train == "LOO") {
    xgb_model <- caret::train(
      X, y,
      method = "xgbTree",
      trControl = caret::trainControl(method = "LOOCV"),
      tuneGrid = xgb_grid
    )
  } 
  
  importance <- as.data.frame(xgboost::xgb.importance(feature_names = predictors, model = xgb_model$finalModel))
  
  return(list("output_data" = output.data, "importance" = importance, "model" = xgb_model))
}

dynfoot_summary_plot_ivd <- function(data, metrics, group, min.length=40) {
  
  data <- do.call(rbind, data)
  
  if (group %in% colnames(data)) {
    
    data <- sort_ews(data, group, metrics)
    
    data <- data %>% filter(ts.length >= min.length)
    
    metrics.norm <- metrics[str_detect(metrics, "full")]
    data[metrics.norm] <- lapply(data[metrics.norm], norm_ts, type="rank")
    
    data <- stats_grouping(data, metrics, group)
    
    names(data)[names(data) == group] <- "clase"
    
    ploties.ews <- list()
    metrics.full <- metrics[str_detect(metrics, "full")]
    
    temp <- data
    
    temp<- temp %>% dplyr::add_count(clase) %>%
      dplyr::mutate(clase = paste0(clase, ' (', n, ')')) %>%
      melt(measure.vars = metrics.full, variable.name = "metric")
    
    temp$labels <- as.character(temp[1,paste0("labels.", temp$metric)])
    
    p1 <- ggplot(temp, aes(x = metric, y = value, fill = clase)) +
      geom_boxplot(outlier.shape = NA, alpha = 0.8, na.rm = TRUE, position = position_dodge()) +
      geom_point(na.rm = TRUE, position = position_jitterdodge(0.05), pch=21) +
      labs(x="metric", y="value") +
      theme(axis.text = element_text(size = 10)) +
      theme(axis.title = element_text(size = 10)) +
      theme(.inside = "right") +
      theme_light() +
      scale_fill_viridis(discrete = TRUE, option = "mako") +
      geom_text(aes(x=metric, y=1.05, label=labels, fontface = "bold"), check_overlap = TRUE) +
      labs(fill = 'class (# obs)')
    
    ploties.ews <- c(ploties.ews, list(p1))
    
    metrics.full <- metrics[str_detect(metrics,"roll")]
    
    temp <- data
    temp <- temp %>% dplyr::add_count(clase) %>%
      dplyr::mutate(clase = paste0(clase, ' (', n, ')')) %>%
      melt(measure.vars = metrics.full, variable.name = "metric")
    temp$labels <- as.character(temp[1,paste0("labels.", temp$metric)])
    
    p1 <- ggplot(temp, aes(x = metric, y = value, fill = clase)) +
      geom_boxplot(outlier.shape = NA, alpha = 0.8, na.rm = TRUE, position = position_dodge()) +
      geom_point(na.rm = TRUE, position = position_jitterdodge(0.05), pch=21) +
      labs(x="metric", y="value") +
      theme(axis.text = element_text(size = 10)) +
      theme(axis.title = element_text(size = 10)) +
      theme(.inside = "right") +
      theme_light() +
      scale_fill_viridis(discrete = TRUE, option = "mako") +
      geom_text(aes(x=metric, y=1.05, label=labels, fontface = "bold"), check_overlap = TRUE) +
      labs(fill = 'class (# obs)')
    
    ploties.ews <- c(ploties.ews, list(p1))
    
    ploties.ews <- plot_grid(plotlist = ploties.ews, nrow = 2)
    
  } else {
    
    message("valid group needed to make statistical comparisons")
    
    data <- data %>% dplyr::group_by(ID) %>%
      dplyr::mutate(ts.length = length(x)) %>%
      dplyr::filter(ts.length >= min.length)
    
    data <- sort_ews(data, group, metrics)
    
    metrics.norm <- metrics[str_detect(metrics,"full")]
    data[metrics.norm] <- lapply(data[metrics.norm], norm_ts, type="rank")
    
    ploties.ews <- list()
    metrics.full <- metrics[str_detect(metrics, "full")]
    
    temp <- data
    
    temp<- temp %>% melt(measure.vars = metrics.full,variable.name = "metric")
    
    p1 <- ggplot(temp, aes(x = metric, y = value, fill = metric)) +
      geom_boxplot(outlier.shape = NA, alpha = 0.8, na.rm = TRUE, position = position_dodge()) +
      geom_point(na.rm = TRUE, position = position_jitterdodge(0.05), pch=21) +
      labs(x="metric", y="value") +
      theme(axis.text = element_text(size = 10)) +
      theme(axis.title = element_text(size = 10)) +
      theme_light() +
      scale_fill_viridis(discrete = TRUE, option = "H")
    
    ploties.ews <- c(ploties.ews, list(p1))
    
    metrics.full <- metrics[str_detect(metrics, "roll")]
    temp <- data
    temp<- temp %>% melt(measure.vars = metrics.full, variable.name = "metric")
    
    p1 <- ggplot(temp, aes(x = metric, y = value, fill = metric)) +
      geom_boxplot(outlier.shape = NA, alpha = 0.8, na.rm = TRUE, position = position_dodge()) +
      geom_point(na.rm = TRUE, position = position_jitterdodge(0.05), pch=21) +
      labs(x="metric", y="value") +
      theme(axis.text = element_text(size = 10)) +
      theme(axis.title = element_text(size = 10)) +
      theme_light() +
      scale_fill_viridis(discrete = TRUE, option = "H")
    
    ploties.ews <- c(ploties.ews, list(p1))
    
    ploties.ews <- plot_grid(plotlist = ploties.ews, nrow = 2)
    
    return(ploties.ews)
    
  }
  
  ploties <- list()
  
  metrics.full = metrics[str_detect(metrics,"full")]
  
  res.comp <- data[metrics.full] %>% drop_na()
  
  pca.out <- PCA(res.comp, graph = FALSE)
  
  p1 = fviz_pca_var(pca.out, col.var = "cos2",
                    gradient.cols = c("black", "blue", "green"),
                    repel = TRUE)
  
  ploties <- c(ploties, list(p1))
  
  cormat <- cor(data[metrics.full], use = "complete.obs", method = "kendall")
  
  get_upper_tri <- function(cormat){
    cormat[upper.tri(cormat)] <- NA
    return(cormat)
  }
  
  melted_cormat <- melt(get_upper_tri(cormat), na.rm = TRUE)
  
  reorder_cormat <- function(cormat){
    dd <- as.dist((1-cormat)/2)
    hc <- hclust(dd)
    cormat <- cormat[hc$order, hc$order]
  }
  
  cormat <- reorder_cormat(cormat)
  upper_tri <- get_upper_tri(cormat)
  
  melted_cormat <- melt(upper_tri, na.rm = TRUE)
  
  p1 <- ggplot(data = melted_cormat %>% dplyr::filter(Var1 != Var2),
               aes(Var1, Var2, fill = value)) +
    geom_tile(color = "white") +
    scale_y_discrete(position = "right") +
    scale_fill_viridis(option = "B", name="kendall correlation") +
    theme_minimal() +
    theme(
      axis.text.x = element_text(angle = 45, vjust = 1, size = 10, hjust = 1),
      axis.text.y = element_text(angle = 0, vjust = 0.5, size = 10, hjust = 1),
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.5, 0.7),
      legend.direction = "horizontal"
    ) +
    coord_fixed() +
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  ploties <- c(ploties, list(p1))
  
  metrics.roll = metrics[str_detect(metrics, "roll")]
  
  res.comp <- data[metrics.roll] %>% drop_na()
  
  pca.out <- PCA(res.comp, graph = FALSE)
  
  p1 = fviz_pca_var(pca.out, col.var = "cos2",
                    gradient.cols = c("black", "blue", "green"),
                    repel = TRUE)
  
  ploties <- c(ploties, list(p1))
  
  cormat=cor(data[metrics.roll], use = "complete.obs", method = "kendall")
  
  get_upper_tri <- function(cormat){
    cormat[upper.tri(cormat)] <- NA
    return(cormat)
  }
  
  melted_cormat <- melt(get_upper_tri(cormat), na.rm = TRUE)
  
  reorder_cormat <- function(cormat){
    dd <- as.dist((1-cormat)/2)
    hc <- hclust(dd)
    cormat <- cormat[hc$order, hc$order]
  }
  
  cormat <- reorder_cormat(cormat)
  upper_tri <- get_upper_tri(cormat)
  
  melted_cormat <- melt(upper_tri, na.rm = TRUE)
  
  p1 <- ggplot(data = melted_cormat %>% dplyr::filter(Var1 != Var2),
               aes(Var1, Var2, fill = value)) +
    geom_tile(color = "white") +
    scale_y_discrete(position = "right") +
    scale_fill_viridis(option = "B",name="kendall correlation") +
    theme_minimal() +
    theme(
      axis.text.x = element_text(angle = 45, vjust = 1, size = 10, hjust = 1),
      axis.text.y = element_text(angle = 0, vjust = 0.5, size = 10, hjust = 1),
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.5, 0.7),
      legend.direction = "horizontal"
    ) +
    coord_fixed() +
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  ploties <- c(ploties, list(p1))
  
  ploties <- plot_grid(plotlist = ploties, nrow = 2)
  
  return(list(box_plot = ploties.ews, PCAcorr = ploties))
  
}

