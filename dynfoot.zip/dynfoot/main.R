source("code/packages.R")
source("code/functions_trajclass.R")
source("code/functions_dynclass_beta.R")

ram_data_classif <- readRDS("data/RAM/classif_v4.61_SProd_minlen25_normTBavg_looTRUE.rds")

ram_data_pre <- readRDS("data/RAM/SProd_RAMLDBv4.61_minlen25.rds")

ram_data_pre <- do.call(rbind,ram_data_pre)
ram_data_pre <- merge(ram_data_pre,ram_data_classif,by = "stockid")
ram_data_pre <- split(ram_data_pre,ram_data_pre$stockid)

ram_data_pre <- lapply(ram_data_pre, function(df) {
  df = as.data.frame(df)
  colnames(df)[colnames(df) == "stockid"] <- "ID"
  colnames(df)[colnames(df) == "year"] <- "x"
  colnames(df)[colnames(df) == "SProd"] <- "y"
  temp = df %>%
    dplyr::select(ID, class, contains("nrmse_") & !nrmse_asd) %>%
    tidyr::pivot_longer(cols = contains("nrmse_"),
                        names_to = "class_nrmse", names_prefix = "nrmse_",
                        values_to = "nrmse") %>%
    dplyr::filter(class==class_nrmse)
  df$nrmse = temp$nrmse
  return(df)
})


ram_data = run_dynfoot(ram_data_pre,metrics.type = "all",detrend.type = "asclassif",cores = 3,filepath = "data/RAM",saveplots = FALSE,group = "class",cut = TRUE)

ram_sum_plots = dynfoot_summary_plot(data = ram_data,metrics = metrics,group = "class",min.length = 20)

ram_sum_plots$box_plot

ram_sum_plots$PCAcorr

EWS_data_ram = brt.model(sort_ews(data = do.call(rbind,ram_data),group = "class",metrics = metrics)%>%filter(ts.length>19),target = "class",predictors = metrics)

EWS_data_ram = run_ml_model(ram_data,target = "class",predictors = metrics)

conf.matrix.plot(EWS_data_ram$output_data)

######### ICES Atlantic Cod database ##########

raw_data_ices <- read_csv(file = "data/ICES/cod_north_sea_subarea.csv")

raw_data_ices <- raw_data_ices %>% group_by(SubArea) %>% filter(length(Year)>20)

raw_data_ices <- split(raw_data_ices,raw_data_ices$SubArea)

ices_data_pre <- lapply(raw_data_ices, function(df) {
  df = as.data.frame(df)
  colnames(df)[colnames(df) == "SubArea"] <- "ID"
  colnames(df)[colnames(df) == "Year"] <- "x"
  colnames(df)[colnames(df) == "CPUE_all_age"] <- "y"
  return(df)
})

classif <- run_classif_data(ices_data_pre,str = "aic_asd",run_loo = FALSE,showplots = FALSE,two_bkps = FALSE,smooth_signif = FALSE,variable = "y",save_plot = FALSE,group = "ID",time = "x",asd_thr = c(0.15))

classif<-split(classif$traj_ts_full,classif$traj_ts_full$simu_id)

ices_data_pre<-mapply(c, ices_data_pre, classif, SIMPLIFY=FALSE)

ices_data_pre <- lapply(ices_data_pre, as.data.frame)

ices_data_pre <- lapply(ices_data_pre, function(df) {
  temp = df %>%
    dplyr::select(ID, class, contains("nrmse_") & !nrmse_asd) %>%
    tidyr::pivot_longer(cols = contains("nrmse_"),
                        names_to = "class_nrmse", names_prefix = "nrmse_",
                        values_to = "nrmse") %>%
    dplyr::filter(class==class_nrmse)
  df$nrmse = temp$nrmse
  return(df)
})

ices_data = run_dynfoot(ices_data_pre,metrics.type = "all",detrend.type = "asclassif",cores = 3,filepath = "data/ICES",saveplots = FALSE,group = "class",cut = TRUE)

ices_sum_plots = dynfoot_summary_plot(data = ices_data,metrics = metrics,group = "class",min.length = 20)

ices_sum_plots$box_plot

ices_sum_plots$PCAcorr

EWS_data_ices = brt.model(sort_ews(data = do.call(rbind,ices_data),group = "class",metrics = metrics)%>%filter(ts.length>19),target = "class",predictors = metrics)

ices_data = run_dynfoot(ices_data_pre,metrics.type = "all",detrend.type = "asclassif",cores = 3,filepath = "data/ICES",saveplots = FALSE,group = "class",cut = TRUE)
EWS_data_ices = run_ml_model(ices_data,target = "class",predictors = metrics)
conf.matrix.plot(EWS_data_ices$output_data)

############ FishGlob dataset ###########

# Load the dataset:
load("/Users/alejandro/Documents/biodicee/fishATrisk/data/FishGlob/AquaAuma-FishGlob_data-508ea5f/outputs/Compiled_data/FishGlob_public_std_clean.RData")

# Transform to get relevant data
# wgt: Total fish weight by haul (= sample)
# cpua: Catch per unit of area
mod_df <- data %>%
  dplyr::group_by(survey_unit, accepted_name, year) %>%
  # retrieve wgt_cpua for cases were it is not already computed (check if relevant)
  dplyr::mutate(wgt_cpua = ifelse((wgt_cpua==0 | is.na(wgt_cpua)) &
                                    (wgt!=0 & !is.na(wgt)) &
                                    (area_swept!=0 & !is.na(wgt)),
                                  wgt/area_swept, wgt_cpua)) %>%
  dplyr::summarise(wgt_cpua_mean = mean(wgt_cpua)) %>%
  dplyr::mutate(ts_id = paste(accepted_name, survey_unit, sep="_")) %>%
  dplyr::group_by(ts_id) %>%
  tidyr::drop_na() %>%
  dplyr::filter(wgt_cpua_mean != 0) %>% # remove constant zero time series
  dplyr::mutate(nn = n()) %>%
  dplyr::filter(nn>=40) %>%
  dplyr::relocate(year)

mod_df %>%
  dplyr::group_by(survey_unit, accepted_name) %>%
  dplyr::summarise(mean=mean(wgt_cpua_mean))

# Number of time series (=species) by survey
mod_df %>%
  dplyr::group_by(survey_unit, accepted_name) %>%
  dplyr::slice(1) %>%
  dplyr::group_by(survey_unit) %>%
  summarise(n=n())

# Average length of time series (in number of points not time span as there are missing points)
mod_df %>%
  dplyr::group_by(survey_unit, accepted_name) %>%
  dplyr::slice(1) %>%
  dplyr::pull(nn) %>%
  mean()
# 48.38225

raw_data_fg <- split(mod_df,mod_df$ts_id)

raw_data_fg <- lapply(raw_data_fg, function(df) {
  df = as.data.frame(df)
  colnames(df)[colnames(df) == "ts_id"] <- "ID"
  colnames(df)[colnames(df) == "year"] <- "x"
  colnames(df)[colnames(df) == "wgt_cpua_mean"] <- "y"
  return(df)
})

classif <- run_classif_data(raw_data_fg,str = "aic_asd",run_loo = FALSE,showplots = FALSE,two_bkps = FALSE,smooth_signif = FALSE,variable = "y",save_plot = FALSE,group = "ID",time = "x",asd_thr = c(0.15))

classif<-split(classif$traj_ts_full,classif$traj_ts_full$simu_id)

fg_data_pre<-mapply(c, raw_data_fg, classif, SIMPLIFY=FALSE)

fg_data_pre = lapply(fg_data_pre, as.data.frame)

fg_data_pre <- lapply(fg_data_pre, function(df) {
  temp = df %>%
    dplyr::select(ID, class, contains("nrmse_") & !nrmse_asd) %>%
    tidyr::pivot_longer(cols = contains("nrmse_"),
                        names_to = "class_nrmse", names_prefix = "nrmse_",
                        values_to = "nrmse") %>%
    dplyr::filter(class==class_nrmse)
  df$nrmse = temp$nrmse
  return(df)
})

fg_data = run_dynfoot(fg_data_pre,metrics.type = "all",detrend.type = "asclassif",cores = 3,filepath = "data/FishGlob/",saveplots = FALSE,group = "class",cut = TRUE)

fg_sum_plots = dynfoot_summary_plot(data = fg_data,metrics = metrics,group = "class",min.length = 20)

fg_sum_plots$box_plot

fg_sum_plots$PCAcorr

EWS_data_fg = brt.model(sort_ews(data = do.call(rbind,fg_data),group = "class",metrics = metrics)%>%filter(ts.length>19),target = "class",predictors = metrics)

fg_data = run_dynfoot(fg_data_pre,metrics.type = "all",detrend.type = "asclassif",cores = 3,filepath = "data/FishGlob/",saveplots = FALSE,group = "class",cut = TRUE)
EWS_data_fg = run_ml_model(fg_data,target = "class",predictors = metrics)
conf.matrix.plot(EWS_data_fg$output_data)

############ simulated dataset ###########

simu_list <- readRDS(file = "data/simu/all_simu_eig_60_r1.rds")

simu_df_kept <- do.call(rbind,simu_list) %>% filter(iter<=10) %>% mutate(id = paste0(scen,"_sr",sr,"_iter",iter),loc_brk_chg=60) %>% dplyr::select(!scen)

names(simu_df_kept)[names(simu_df_kept)=="expected_class"]<-"class"
names(simu_df_kept)[names(simu_df_kept)=="id"]<-"ID"

simu_data_pre <- split(simu_df_kept,simu_df_kept$ID)

simu_data_pre <- lapply(simu_data_pre, function(df) {
  df = as.data.frame(df)
  colnames(df)[colnames(df) == "year"] <- "x"
  colnames(df)[colnames(df) == "TB"] <- "y"
  return(df)
})

simu_data = run_dynfoot(simu_data_pre,metrics.type = "all",detrend.type = "asclassif",cores = 3,filepath = "data/simu",saveplots = FALSE,group = "class",cut = TRUE)

simu_sum_plots = dynfoot_summary_plot(data = simu_data,metrics = metrics,group = "class",min.length = 20)

simu_sum_plots$box_plot

simu_sum_plots$PCAcorr

EWS_data_simu_Lnoise = run_ml_model(sort_ews_simu(data = do.call(rbind,simu_data),group = "class",metrics = metrics)%>%filter(ts.length>19,sr==0.01),target = "class",predictors = metrics)

EWS_data_simu_Hnoise = run_ml_model(sort_ews_simu(data = do.call(rbind,simu_data),group = "class",metrics = metrics)%>%filter(ts.length>19,sr==0.1),target = "class",predictors = metrics)

#################

ploties.ts <- list()

temp <- ram_data %>% filter(stockid == "GOLDREDNEAR")
temp$time<-temp$year
p1 <- ggplot() +
  geom_line(data = temp, aes(x = time, y = TB), linewidth = 1.5) +  # Thicker first line
  geom_line(data = temp, aes(x = time, y = TB_model), linetype = "dashed", color = "red", size = 1.5) +  # Thicker, red dashed second line
  theme_minimal() + labs(y = "productivity")

p2 <- ggplot(data=temp,aes(x=time,xend=time,y=0,yend=TB_res))+geom_segment(linewidth = 1.5)+ylab("residuals")+theme_minimal()

p3 <- plot.dynamical.footprint(EWS_data_ram,"ID","GOLDREDNEAR",metrics)

ploties.ts <- c(ploties.ts,list(p1),list(p2),list(p3))

plot_grid(plotlist = ploties.ts,nrow = 1)

#################

ploties.ts <- list()

p1 <- conf.matrix.plot(EWS_data_ram)

p2 <- conf.matrix.plot(EWS_data_ices)

p3 <- conf.matrix.plot(EWS_data_fg)

ploties.ts <- c(ploties.ts,list(p1),list(p2),list(p3))

plot_grid(plotlist = ploties.ts,nrow = 1)

#################

ploties.ts <- list()

p1 <- violin.prob.plot(EWS_data_ram)

p2 <- violin.prob.plot(EWS_data_ices)

p3 <- violin.prob.plot(EWS_data_fg)

ploties.ts <- c(ploties.ts,list(p1),list(p2),list(p3))

plot_grid(plotlist = ploties.ts,nrow = 1)

################

ploties.ts <- list()

temp <- do.call(rbind,ram_data) %>% filter(ID == "HADICE")
temp$time<-temp$x
p1 <- ggplot() +
  geom_line(data = temp, aes(x = time, y = y), linewidth = 1.5) +  # Thicker first line
  geom_line(data = temp, aes(x = time, y = y_model), linetype = "dashed", color = "red", linewidth = 1.5) +  # Thicker, red dashed second line
  theme_minimal() + labs(y = "productivity")

temp <- do.call(rbind,ices_data) %>% filter(ID == "48F0")
temp$time<-temp$x
p2 <- ggplot() +
  geom_line(data = temp, aes(x = time, y = y), linewidth = 1.5) +  # Thicker first line
  geom_line(data = temp, aes(x = time, y = y_model), linetype = "dashed", color = "red", size = 1.5) +  # Thicker, red dashed second line
  theme_minimal() + labs(y = "CPUE")

temp <- do.call(rbind,fg_data) %>% filter(ID == "Alosa sapidissima_NEUS-Spring")
temp$time<-temp$x
p3 <- ggplot() +
  geom_line(data = temp, aes(x = time, y = y), linewidth = 1.5) +  # Thicker first line
  geom_line(data = temp, aes(x = time, y = y_model), linetype = "dashed", color = "red", size = 1.5) +  # Thicker, red dashed second line
  theme_minimal() + labs(y = "CPUE")

ploties.ts <- c(ploties.ts,list(p1),list(p2),list(p3))

plot_grid(plotlist = ploties.ts,nrow = 1)

####### Fig S1 ##########

ploties.ts <- list()

p1 = ggplot(EWS_data_ram, aes(x = class, y = 1-nrmse)) +
  geom_boxplot(aes(fill = class), alpha = 0.5) +  # Violin plot for distribution
  geom_jitter(aes(color = class,size = (weight_aic)), width = 0.2, alpha = 0.7) +  # Scatter points for each sample
  theme_minimal() +
  ylab("1 - NRMSE") +
  xlab("class") +
  theme(legend.position = "none") + scale_fill_viridis(option = "H",discrete = TRUE) + scale_color_viridis(option = "H",discrete = TRUE) + scale_size_continuous(range = c(1, 3)) + coord_cartesian(ylim = c(0, 1))

p2 = ggplot(EWS_data_ices, aes(x = class, y = 1-nrmse)) +
  geom_boxplot(aes(fill = class), alpha = 0.5) +  # Violin plot for distribution
  geom_jitter(aes(color = class,size = (weight_aic)), width = 0.2, alpha = 0.7) +  # Scatter points for each sample
  theme_minimal() +
  ylab("1 - NRMSE") +
  xlab("class") +
  theme(legend.position = "none") + scale_fill_viridis(option = "H",discrete = TRUE) + scale_color_viridis(option = "H",discrete = TRUE) + scale_size_continuous(range = c(1, 3)) + coord_cartesian(ylim = c(0, 1))

p3 = ggplot(EWS_data_fg, aes(x = class, y = 1-nrmse)) +
  geom_boxplot(aes(fill = class), alpha = 0.5) +  # Violin plot for distribution
  geom_jitter(aes(color = class,size = (weight_aic)), width = 0.2, alpha = 0.7) +  # Scatter points for each sample
  theme_minimal() +
  ylab("1 - NRMSE") +
  xlab("class") +
  theme(legend.position = "none") + scale_fill_viridis(option = "H",discrete = TRUE) + scale_color_viridis(option = "H",discrete = TRUE) + scale_size_continuous(range = c(1, 3)) + coord_cartesian(ylim = c(0, 1))

ploties.ts <- c(ploties.ts,list(p1),list(p2),list(p3))

plot_grid(plotlist = ploties.ts,nrow = 1)

##########

ploties.ts <- list()

p1 = ggplot(ram_data %>% group_by(stockid) %>% filter(class == "abrupt") %>% summarise(shift = unique(loc_brk_chg)), aes(x = shift)) +
  geom_density(aes(y = after_stat(count)), color = "gray", fill = "lightgray", alpha = 0.3) +
  geom_bar() + scale_x_continuous(limits = c(1920, 2020), expand = c(0.1, 0)) +
  theme_minimal() +
  ylab("count") +
  xlab("year of detected abrupt shift")

p2 = ggplot(ices_data %>% group_by(SubArea) %>% filter(class == "abrupt") %>% summarise(shift = unique(loc_brk_chg)), aes(x = shift)) +
  geom_density(aes(y = after_stat(count)), color = "gray", fill = "lightgray", alpha = 0.3) +
  geom_bar() + scale_x_continuous(limits = c(1920, 2020), expand = c(0.1, 0)) +
  theme_minimal() +
  ylab("count") +
  xlab("year of detected abrupt shift")

p3 = ggplot(fg_data %>% group_by(ts_id) %>% filter(class == "abrupt") %>% summarise(shift = unique(loc_brk_chg)), aes(x = shift)) +
  geom_density(aes(y = after_stat(count)), color = "gray", fill = "lightgray", alpha = 0.3) +
  geom_bar() + scale_x_continuous(limits = c(1920, 2020), expand = c(0.1, 0)) +
  theme_minimal() +
  ylab("count") +
  xlab("year of detected abrupt shift")

ploties.ts <- c(ploties.ts,list(p1),list(p2),list(p3))

plot_grid(plotlist = ploties.ts,nrow = 3)

#############

ploties.ts <- list()

p1 = ram_sum_plots$box_plot

p2 = ices_sum_plots$box_plot

p3 = fg_sum_plots$box_plot

ploties.ts <- c(ploties.ts,list(p1),list(p2),list(p3))

plot_grid(plotlist = ploties.ts,nrow = 3)

#############

ploties.ts <- list()

p1 = ram_sum_plots$PCAcorr

p2 = ices_sum_plots$PCAcorr

p3 = fg_sum_plots$PCAcorr

ploties.ts <- c(ploties.ts,list(p1),list(p2),list(p3))

plot_grid(plotlist = ploties.ts,nrow = 3)

########### importance plot

long_data <- total_importance %>%
  pivot_longer(cols = starts_with("gain"),
               names_to = "Category",
               values_to = "Gain") %>%
  pivot_longer(cols = c(ram, hsiao, fg, sim),
               names_to = "Source",
               values_to = "Feature") %>%
  filter(Category == paste0("gain_", Source))

# Set the order of the 'Source' factor to ram, hsiao, fg, sim
long_data$Source <- factor(long_data$Source, levels = c("ram", "hsiao", "fg", "sim"),labels = c("RAM", "ICES", "FishGlob", "Simulated"))

# Reorder the 'Feature' column based on the 'Gain' values
long_data$Feature <- reorder(long_data$Feature, long_data$Gain, FUN = sum,decreasing = TRUE)

# Create the bar plot
ggplot(long_data, aes(x = Feature, y = Gain, fill = Source)) +
  geom_bar(stat = "identity", position = "dodge") +
  scale_fill_viridis_d(option = "B",begin = 0.2,end = 0.9) +
  theme_minimal() +
  labs(x = "metric", y = "gain", fill = "dataset") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

#####################

ploties.ts <- list()

p1 <- conf.matrix.plot(EWS_data_simu_Lnoise)

p2 <- conf.matrix.plot(EWS_data_simu_Hnoise)

p3 <- plot.roc(EWS_data_simu_Lnoise)

p4 <- plot.roc(EWS_data_simu_Hnoise)

ploties.ts <- c(ploties.ts,list(p1),list(p2),list(p3),list(p4))

plot_grid(plotlist = ploties.ts,nrow = 2)

#####################

ploties.ts <- list()

p1 <- violin.prob.plot(EWS_data_simu)

p2 <- violin.prob.plot(EWS_data_simu_high)

ploties.ts <- c(ploties.ts,list(p1),list(p2))

plot_grid(plotlist = ploties.ts,nrow = 1)

####################

ggplot(EWS_data_fg%>%mutate(correcto=ifelse(class==Predictedclass,TRUE,FALSE))%>%filter(weight_aic>0.25),aes(x=weight_aic,y=MaxProbability,shape = Predictedclass,color = correcto)) + geom_point() + scale_color_viridis_d(option = "B",begin = 0.2,end = 0.9,direction = -1)


####################

ploties.ts <- list()

p1 = ggplot(EWS_data_ram, aes(x = ts.length)) +
  geom_bar(aes(y = after_stat(count)), fill = "lightyellow", color = "black", alpha = 0.8) +
  geom_density(aes(y = after_stat(count)), color = "gray", fill = "lightgray", alpha = 0.3) +
  theme_minimal() +
  labs(x = "Time Series Length", y = "Count")

p2 = ggplot(EWS_data_ices, aes(x = ts.length)) +
  geom_bar(aes(y = after_stat(count)), fill = "lightblue", color = "black", alpha = 0.8) +
  geom_density(aes(y = after_stat(count)), color = "gray", fill = "lightgray", alpha = 0.3) +
  theme_minimal() +
  labs(x = "Time Series Length", y = "Count")

p3 = ggplot(EWS_data_fg, aes(x = ts.length)) +
  geom_bar(aes(y = after_stat(count)), fill = "pink", color = "black", alpha = 0.8) +
  geom_density(aes(y = after_stat(count)), color = "gray", fill = "lightgray", alpha = 0.3) + 
  theme_minimal() +
  labs(x = "Time Series Length", y = "Count")

ploties.ts <- c(ploties.ts,list(p1),list(p2),list(p3))

plot_grid(plotlist = ploties.ts,nrow = 3)

################### confusion matrix

reduced.conf.matrix.plot <- function(data) {
  
  # Define the desired order of class levels
  desired_order <- c("abrupt", "non-abrupt")
  
  data = data%>%mutate(class2=ifelse(class=="abrupt","abrupt","non-abrupt"),Pclass2=ifelse(Predictedclass=="abrupt","abrupt","non-abrupt"))
  
  # Create a confusion matrix from actual and predicted classes
  cm <- table(data$class2, data$Pclass2)
  
  # Convert confusion matrix to a data frame for plotting
  cm_df <- as.data.frame(cm)
  
  # Ensure factor levels for rows (Var1) and columns (Var2) match the desired order
  cm_df$Var1 <- factor(cm_df$Var1, levels = desired_order)
  cm_df$Var2 <- factor(cm_df$Var2, levels = desired_order)
  
  # Normalize frequencies within each row (actual class) to calculate relative frequencies
  cm_df <- cm_df %>%
    group_by(Var1) %>%
    mutate(RelativeFreq = Freq / sum(Freq))
  
  # Define custom color palette
  custom_palette <- c("#30123BFF", "grey70")
  
  # Assign colors to each class based on column order
  cm_df <- cm_df %>%
    mutate(Color = custom_palette[as.numeric(as.factor(Var1))])
  
  # Calculate sensitivities (true positive rate) for each class
  actual_totals <- rowSums(cm[desired_order, desired_order])  # Total actual occurrences per class
  true_positives <- diag(cm[desired_order, desired_order])   # True positives per class
  sensitivities <- true_positives / actual_totals
  
  # Create a data frame for sensitivity annotations
  sensitivity_labels <- data.frame(
    Class = factor(desired_order, levels = desired_order),
    Sensitivity = sprintf("%.2f", sensitivities)  # Format sensitivities to two decimal places
  )
  
  # Generate the confusion matrix plot using ggplot2
  ggplot(data = cm_df, mapping = aes(x = Var1, y = Var2)) +
    geom_tile(aes(fill = Color, alpha = RelativeFreq), color = "white") +  # Tiles with color and transparency based on RelativeFreq
    ylab("predicted shape class") + xlab("actual shape class") +
    geom_text(aes(label = sprintf("%1.0f", Freq)), vjust = 1) +            # Add frequency text to tiles
    scale_fill_identity() +                                               # Use fixed colors from custom palette
    scale_alpha(range = c(0.5, 1)) +                                      # Adjust transparency range
    theme_minimal() +
    theme(
      legend.position = "none",                                           # Remove legend
      panel.grid = element_blank()                                        # Remove grid lines
    ) +
    geom_text(data = sensitivity_labels, aes(x = Class, y = ncol(cm) + 0.6, label = Sensitivity),
              inherit.aes = FALSE, size = 4, fontface = "bold") +         # Annotate sensitivities above columns
    coord_cartesian(ylim = c(1, ncol(cm) + 0.1))                          # Extend y-axis to fit sensitivity labels
  
}

############# LENGTH TESTS

data = rbind(EWS_data_ram,EWS_data_ices,EWS_data_fg)

ggplot(data %>% filter(class=="abrupt"), aes(x = ifelse(class==Predictedclass,"correct","incorrect"), y = ts.length)) +
  geom_violin(, trim = TRUE, alpha = 0.5) +   # Violin plots with transparency
  geom_jitter(aes(color = class), width = 0.2, alpha = 0.7) +           # Jittered points for individual samples
  theme_minimal() +
  ylab("ts length") +
  xlab("shape class prediction") +
  theme(legend.position = "none") +                                     # Remove legend for simplicity
  scale_fill_viridis(option = "H", discrete = TRUE) +                   # Use Viridis color palette for fill colors
  scale_color_viridis(option = "H", discrete = TRUE) +                  # Use Viridis palette for point colors
  scale_size_continuous(range = c(1, 3)) 


+                              # Adjust point sizes if needed
  geom_hline(yintercept = 0.25, linetype = "dashed", color = "black") 


+ # Add a reference line at probability threshold (e.g., random chance)
  coord_cartesian(ylim = c(0, 1))                                       # Limit y-axis to [0,1] range

####################

ploties.ts <- list()

p1 = ggplot(EWS_data_ram, aes(x = ts.length, y = MaxProbability, colour = class)) +
  geom_point() +  scale_color_viridis(option = "H",discrete = TRUE) +
  theme_minimal() +
  labs(x = "time series length", y = "classification probability")

p2 = ggplot(EWS_data_ices, aes(x = ts.length, y = MaxProbability, colour = class)) +
  geom_point() +  scale_color_viridis(option = "H",discrete = TRUE) +
  theme_minimal() +
  labs(x = "time series length", y = "classification probability")

p3 = ggplot(EWS_data_fg, aes(x = ts.length, y = MaxProbability, colour = class)) +
  geom_point() +  scale_color_viridis(option = "H",discrete = TRUE) +
  theme_minimal() +
  labs(x = "time series length", y = "classification probability")

ploties.ts <- c(ploties.ts,list(p1),list(p2),list(p3))

plot_grid(plotlist = ploties.ts,nrow = 3)

####################

pie_chart <- function(df_sum, title=NULL, size=7, size_caption=15,
                      no_text=FALSE, no_caption=FALSE){
  
  df_sum <- df_sum %>%
    dplyr::mutate(p = n/sum(n)*100)
  
  innerCircleData <- df_sum %>%
    dplyr::group_by(traj) %>%
    dplyr::summarise(tot_rev = sum(p)) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(
      ymax = cumsum(tot_rev),
      ymin = lag(ymax, n = 1, default = 0),
      csum = rev(cumsum(rev(tot_rev))),
      pos = tot_rev/2 + lead(csum, 1),
      pos = if_else(is.na(pos), tot_rev/2, pos)
    )
  
  innerCircle <- ggplot(innerCircleData)+
    geom_rect(aes(xmin = 0, xmax = 3, ymin = ymin, ymax = ymax, fill = traj),
              color = "black")+
    scale_fill_manual(values =
                        c("abrupt" = "#800080", "potential_abrupt" = "#CF9FFF",
                          "non_abrupt" = "grey70"))+
    xlim(0, 4)+
    theme_bw()+
    coord_polar(theta = "y")
  
  if(!no_text){
    innerCircle <- innerCircle+
      geom_text(aes(x=1.7, y=tot_rev,
                    label = paste0(stringr::str_to_title(traj),"\n",
                                   round(tot_rev,digits=1),"%")),
                position = position_stack(vjust = 0.5),
                size=size)
  }
  
  sunburst <- innerCircle+
    theme_void()+
    theme(legend.position="none",
          plot.caption = element_text(hjust = 0.8, vjust = 1, size=size_caption),
          plot.title = element_text(vjust = 1, size=15))+
    ggtitle(title)
  
  if(!no_caption){
    
    sunburst <- sunburst+
      labs(caption = paste("N =", sum(df_sum$n)))
  }
  
  return(sunburst)
  
}

pie_chart_fg <- function(df_sum, title=NULL, size=7, size_caption=15,
                         no_text=FALSE, no_caption=FALSE){
  
  df_sum <- df_sum %>%
    dplyr::mutate(p = n/sum(n)*100)
  
  innerCircleData <- df_sum %>%
    dplyr::group_by(traj) %>%
    dplyr::summarise(tot_rev = sum(p)) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(
      ymax = cumsum(tot_rev),
      ymin = lag(ymax, n = 1, default = 0),
      csum = rev(cumsum(rev(tot_rev))),
      pos = tot_rev/2 + lead(csum, 1),
      pos = if_else(is.na(pos), tot_rev/2, pos)
    )
  
  innerCircle <- ggplot(innerCircleData)+
    geom_rect(aes(xmin = 0, xmax = 3, ymin = ymin, ymax = ymax, fill = traj),
              color = "red")+
    scale_fill_manual(values =
                        c("abrupt" = "#800080", "potential_abrupt" = "#CF9FFF",
                          "non_abrupt" = "grey70"))+
    xlim(0, 4)+
    theme_bw()+
    coord_polar(theta = "y")
  
  if(!no_text){
    innerCircle <- innerCircle+
      geom_text(aes(x=1.7, y=tot_rev,
                    label = paste0(stringr::str_to_title(traj),"\n",
                                   round(tot_rev,digits=1),"%")),
                position = position_stack(vjust = 0.5),
                size=size)
  }
  
  sunburst <- innerCircle+
    theme_void()+
    theme(legend.position="none",
          plot.caption = element_text(hjust = 0.8, vjust = 1, size=size_caption),
          plot.title = element_text(vjust = 1, size=15))+
    ggtitle(title)
  
  if(!no_caption){
    
    sunburst <- sunburst+
      labs(caption = paste("N =", sum(df_sum$n)))
  }
  
  return(sunburst)
  
}

pie_chart_ices <- function(df_sum, title=NULL, size=7, size_caption=15,
                           no_text=FALSE, no_caption=FALSE){
  
  df_sum <- df_sum %>%
    dplyr::mutate(p = n/sum(n)*100)
  
  innerCircleData <- df_sum %>%
    dplyr::group_by(traj) %>%
    dplyr::summarise(tot_rev = sum(p)) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(
      ymax = cumsum(tot_rev),
      ymin = lag(ymax, n = 1, default = 0),
      csum = rev(cumsum(rev(tot_rev))),
      pos = tot_rev/2 + lead(csum, 1),
      pos = if_else(is.na(pos), tot_rev/2, pos)
    )
  
  innerCircle <- ggplot(innerCircleData)+
    geom_rect(aes(xmin = 0, xmax = 3, ymin = ymin, ymax = ymax, fill = traj),
              color = "green")+
    scale_fill_manual(values =
                        c("abrupt" = "#800080", "potential_abrupt" = "#CF9FFF",
                          "non_abrupt" = "grey70"))+
    xlim(0, 4)+
    theme_bw()+
    coord_polar(theta = "y")
  
  if(!no_text){
    innerCircle <- innerCircle+
      geom_text(aes(x=1.7, y=tot_rev,
                    label = paste0(stringr::str_to_title(traj),"\n",
                                   round(tot_rev,digits=1),"%")),
                position = position_stack(vjust = 0.5),
                size=size)
  }
  
  sunburst <- innerCircle+
    theme_void()+
    theme(legend.position="none",
          # plot.background = element_rect(colour=NA, fill="white"),
          # plot.margin = margin(1,4,1,4, "cm")
          plot.caption = element_text(hjust = 0.8, vjust = 1, size=size_caption),
          plot.title = element_text(vjust = 1, size=15))+
    ggtitle(title)
  
  if(!no_caption){
    
    sunburst <- sunburst+
      labs(caption = paste("N =", sum(df_sum$n)))
  }
  
  return(sunburst)
  
}


library(tidyverse)

dir.create("fig", showWarnings=FALSE)

sf::sf_use_s2(FALSE) # To remove error for intersection

lme <- sf::read_sf(dsn = "data/spatial_data/LME66/", layer = "lmes66gcd")
oceans <- sf::read_sf(dsn = "data/spatial_data/ocean_simpl/",
                      layer = "ocean_simpl") %>%
  dplyr::filter(grepl("Ocean", name)) %>%
  dplyr::rename(LME_NAME = name) %>%
  dplyr::mutate(LME_NUMBER = 67:73)
# Group all LMEs
lme_merge <- lme %>% dplyr::summarise()
# Substract LMEs from oceans
high_seas <- sf::st_difference(oceans, lme_merge)
# Combine LMEs and high sea regions
lmes <- dplyr::bind_rows(lme, high_seas)

# Centroid coordinates of LME
lme_cntrd <- readr::read_csv("data/spatial_data/lme_ocean_centroids.csv")

# Stock LME table
main_lme <- readr::read_csv("data/spatial_data/main_lme.csv")

traj_SProd <- EWS_data_ram %>%
  dplyr::rename(stockid = ID)

main_lme = merge(main_lme,traj_SProd, by="stockid") %>% select(stockid,LME_NAME)

centroids <- lme_cntrd %>%
  dplyr::left_join(
    dplyr::left_join(traj_SProd, main_lme, by="stockid") %>%
      dplyr::group_by(LME_NAME) %>%
      dplyr::summarise(sz=n()) %>%
      dplyr::mutate(N=sz,sz=sqrt(sz+5)*6),
    by="LME_NAME")

traj_SProd_sum_area <- dplyr::left_join(traj_SProd, main_lme, by="stockid") %>%
  split(.$LME_NAME) %>%
  mapply(function(x,y){
    x %>%
      dplyr::mutate(traj = dplyr::case_when(
        class=="abrupt" & Predictedclass == "abrupt" ~ "abrupt",
        class!="abrupt" & Predictedclass == "abrupt" ~"potential_abrupt",
        class=="abrupt" & Predictedclass != "abrupt" ~"abrupt",
        class!="abrupt" & Predictedclass != "abrupt" ~ "non_abrupt")) %>%
      dplyr::group_by(traj) %>%
      dplyr::summarise(n=n()) %>%
      dplyr::mutate(
        spe_class =
          factor(traj,
                 levels = c("abrupt",
                            "potential_abrupt","non_abrupt"))) %>%
      dplyr::ungroup() %>%
      pie_chart(.,
                title=NULL,
                size_caption=8,
                size=2, no_text=TRUE, no_caption=FALSE)
    
  }, x=., y=names(.), SIMPLIFY = FALSE)

centroid_lme <- tibble::tibble(x=centroids$lon,
                               y=centroids$lat,
                               area=centroids$LME_NAME,
                               width=centroids$sz) %>%
  dplyr::right_join(tibble::tibble(area = names(traj_SProd_sum_area),
                                   sunburst=traj_SProd_sum_area),
                    by = "area")

space_lme <- ggplot(lmes)+
  geom_sf()+
  theme_void()+
  ggimage::geom_subview(aes(x=x, y=y, subview=sunburst,
                            width=width, height=width), data=centroid_lme)

plot(space_lme)

pdf(file = "fig/fig_s2_lmes.pdf",
    width=12, height=9)
print(space_lme)
dev.off()

main_lme_fg = data.frame(stockid = EWS_data_fg$ID)

main_lme_fg = main_lme_fg %>%
  dplyr::mutate(LME_NAME = dplyr::case_when(
    str_detect(stockid,"EBS") ~ "East Bering Sea FG",
    str_detect(stockid,"AI") ~ "Aleutian Islands  FG",
    str_detect(stockid,"GOA") ~ "Gulf of Alaska  FG",
    str_detect(stockid,"DFO") | str_detect(stockid,"WCANN") | str_detect(stockid,"WCTRI") ~ "California Current  FG",
    str_detect(stockid,"GMEX") ~ "Gulf of Mexico  FG",
    str_detect(stockid,"SEUS") ~ "Southeast U.S. Continental Shelf  FG",
    str_detect(stockid,"NEUS") ~ "Northeast U.S. Continental Shelf  FG",
    str_detect(stockid,"SCS") ~ "Scotian Shelf  FG",
    str_detect(stockid,"GSL-S") ~ "Labrador - Newfoundland  FG",
    str_detect(stockid,"GSL-N") ~ "Labrador - Newfoundland  FG",
    str_detect(stockid,"Nor-BTS") ~ "Norwegian Sea  FG",
    str_detect(stockid,"NS-IBTS") ~ "North Sea  FG",
    str_detect(stockid,"SWC-IBTS") ~ "North Sea  FG",
    str_detect(stockid,"SP-NORTH") ~ "Iberian Coastal  FG",
    str_detect(stockid,"PT-IBTS") ~ "Iberian Coastal  FG"))

traj_SProd <- EWS_data_fg %>%
  dplyr::rename(stockid = ID)

traj_SProd_sum_area <- dplyr::left_join(traj_SProd, main_lme_fg, by="stockid") %>%
  split(.$LME_NAME) %>%
  mapply(function(x,y){
    x %>%
      dplyr::mutate(traj = dplyr::case_when(
        class=="abrupt" & Predictedclass == "abrupt" ~ "abrupt",
        class!="abrupt" & Predictedclass == "abrupt" ~"potential_abrupt",
        class=="abrupt" & Predictedclass != "abrupt" ~"abrupt",
        class!="abrupt" & Predictedclass != "abrupt" ~ "non_abrupt")) %>%
      dplyr::group_by(traj) %>%
      dplyr::summarise(n=n()) %>%
      dplyr::mutate(
        spe_class =
          factor(traj,
                 levels = c("abrupt",
                            "potential_abrupt","non_abrupt"))) %>%
      dplyr::ungroup() %>%
      pie_chart_fg(.,
                   title=NULL,
                   size_caption=8,
                   size=2, no_text=TRUE, no_caption=TRUE)
    
  }, x=., y=names(.), SIMPLIFY = FALSE)

centroid_lme <- tibble::tibble(x=centroids$lon,
                               y=centroids$lat,
                               area=centroids$LME_NAME,
                               width=centroids$sz) %>%
  dplyr::right_join(tibble::tibble(area = names(traj_SProd_sum_area),
                                   sunburst=traj_SProd_sum_area),
                    by = "area")

space_lme <- ggplot(lmes)+
  geom_sf()+
  theme_void()+
  ggimage::geom_subview(aes(x=x, y=y, subview=sunburst,
                            width=width, height=width), data=centroid_lme)

plot(space_lme)

pdf(file = "fig/fig_s2_lmes_fg.pdf",
    width=12, height=9)
print(space_lme)
dev.off()

main_lme_ices = data.frame(stockid = EWS_data_ices$ID)

main_lme_ices = main_lme_ices %>%
  dplyr::mutate(LME_NAME = dplyr::case_when(
    !str_detect(stockid,"hehehe") ~ "North Sea ICES"))

traj_SProd = rbind(EWS_data_ram,EWS_data_ices,EWS_data_fg)

centroids = rbind(centroids,centroids_ices,centroids_fg)

centroids <- centroids %>%
  dplyr::group_by(LME_NAME) %>%
  dplyr::summarise(sz=n()) %>%
  dplyr::mutate(sz=sqrt(sz+5)*6)

traj_SProd <- traj_SProd %>%
  dplyr::rename(stockid = ID)

traj_SProd_sum_area <- dplyr::left_join(traj_SProd, rbind(main_lme,main_lme_ices,main_lme_fg), by="stockid") %>%
  split(.$LME_NAME) %>%
  mapply(function(x,y){
    x %>%
      dplyr::mutate(traj = dplyr::case_when(
        class=="abrupt" & Predictedclass == "abrupt" ~ "abrupt",
        class!="abrupt" & Predictedclass == "abrupt" ~"potential_abrupt",
        class=="abrupt" & Predictedclass != "abrupt" ~"abrupt",
        class!="abrupt" & Predictedclass != "abrupt" ~ "non_abrupt")) %>%
      dplyr::group_by(traj) %>%
      dplyr::summarise(n=n()) %>%
      dplyr::mutate(
        spe_class =
          factor(traj,
                 levels = c("abrupt",
                            "potential_abrupt","non_abrupt"))) %>%
      dplyr::ungroup() %>%
      pie_chart(.,
                title=NULL,
                size_caption=8,
                size=2, no_text=TRUE, no_caption=FALSE)
    
  }, x=., y=names(.), SIMPLIFY = FALSE)

centroid_lme <- tibble::tibble(x=centroids$lon,
                               y=centroids$lat,
                               area=centroids$LME_NAME,
                               width=centroids$sz) %>%
  dplyr::right_join(tibble::tibble(area = names(traj_SProd_sum_area),
                                   sunburst=traj_SProd_sum_area),
                    by = "area")

space_lme <- ggplot(lmes)+
  geom_sf()+
  theme_void()+
  ggimage::geom_subview(aes(x=x, y=y, subview=sunburst,
                            width=width, height=width), data=centroid_lme)

plot(space_lme)

pdf(file = "fig/fig_s2_lmes2.pdf",
    width=12, height=9)
print(space_lme)
dev.off()
